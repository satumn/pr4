import 'package:flutter/material.dart';

void main() {  runApp(const MyApp());}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.purple),
        useMaterial3: true,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<String> items = List.generate(100, (index) => 'Item ${index + 1}');
  int counter = 1;
  void addItem() {
    setState(() {
      items.add('new item ${counter}');
      counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: items
              .map((item) => GestureDetector(
            key: ValueKey(item),
            onTap: () => setState(() => items.remove(item)),
            child: Text(item),
          ))
              .toList(),
        ),
      ),
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: addItem,
            tooltip: 'add new item',
            child: const Text('+'),
          ),
          FloatingActionButton(
            onPressed: () {Navigator.push(context, MaterialPageRoute(builder: (context) => MyHomePage1()));},
            child: const Text('next'),
          ),
        ],
      ),
    );
  }
}

class MyHomePage1 extends StatefulWidget {
  const MyHomePage1({super.key});
  @override
  _MyHomePage1State createState() => _MyHomePage1State();
}

class _MyHomePage1State extends State<MyHomePage1> {
  List<String> items = List.generate(100, (index) => 'Item ${index + 1}');
  int counter = 1;
  void addItem() {
    setState(() {
      items.add('new item ${counter}');
      counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        reverse: true,
        children: items
            .map((item) => GestureDetector(
          key: ValueKey(item),
          onTap: () => setState(() => items.remove(item)),
          child: Text(item),
        ))
            .toList(),
      ),
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: addItem,
            tooltip: 'add new item',
            child: const Text('+'),
          ),
          FloatingActionButton(
            onPressed: () {Navigator.pop(context);},
            child: const Text('previous'),
          ),
          FloatingActionButton(
            onPressed: () {Navigator.push(context,
                MaterialPageRoute(builder: (context) => MyHomePage2()));},
            child: const Text('next'),
          ),
        ],
      ),
    );
  }
}

class MyHomePage2 extends StatefulWidget {
  const MyHomePage2({super.key});
  @override
  _MyHomePage2State createState() => _MyHomePage2State();
}

class _MyHomePage2State extends State<MyHomePage2> {
  List<String> items = List.generate(100, (index) => 'Item ${index + 1}');
  int counter = 1;
  void addItem() {
    setState(() {
      items.add('new item ${counter}');
      counter++;
    });
  }
  void removeItem(int index) {
    setState(() {
      items.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.separated(
        scrollDirection: Axis.vertical,
        itemBuilder: (_, position) => GestureDetector(
          onTap: () => removeItem(position),
          child: Text(items[position]),),
        separatorBuilder: (_, __) => const Divider(),
        itemCount: items.length,
      ),
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: addItem,
            tooltip: 'add new item',
            child: const Text('+'),
          ),
          FloatingActionButton(
            onPressed: () {Navigator.pop(context);},
            child: const Text('previous'),
          ),
        ],
      ),
    );
  }
}
